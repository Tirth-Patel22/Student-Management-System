import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Student {
    int sid;
    String fname;
    String lname;
    int age;
    String dob;
    String mobileno;
    String address;
    double credit;
    int depid;
    int cid;
    double fees;
  
    public Student() {
    }

    public String toString() {
        return "sid=" + sid + ",\nFirst Name=" + fname + ",\nLast Name=" + lname + ",\nAge=" + age + ",\nDate of Birth=" + dob
                + ",\nMobile No=" + mobileno + ",\nAddress=" + address + ",\nCredit=" + credit + ",\nDepid=" + depid
                + ",\nCid=" + cid + ",\nFees=" + fees + "";
    }

    public Student(int sid, String fname, String lname, int age, String dob, String mobileno, String address, double credit, int depid,
            int cid, double fid) {
        this.sid = sid;
        this.fname = fname;
        this.lname = lname;
        this.age = age;
        this.dob = dob;
        this.mobileno = mobileno;
        this.address=address;
        this.credit = credit;
        this.depid = depid;
        this.cid = cid;
        this.fees = fid;
    }

    public void findParticularStudent(){
        System.out.println(SMS.hm);
    }
    public boolean check(String dob){
        boolean result=true;
        for(int i=0;i<dob.length();i++){
            if(Character.isAlphabetic(dob.charAt(i)) || dob.contains(" ")){
                result=false;
                break;
            }else{
                continue;
            }
        }
        return result;
    }
    public boolean checkname(String name){
        boolean result=true;
        for(int i=0;i<name.length();i++){
            if(Character.isAlphabetic(name.charAt(i))){
                continue;
            }else if(name.contains(" ")){
                result=false;
                break;
            }else{
                result=false;
                break;
            }
        }
        return result;
    }
    public static boolean isValidDateOfBirth(String dob) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateOfBirth;

        try {
            dateOfBirth = LocalDate.parse(dob, dateFormatter);
        } catch (DateTimeParseException e) {
            return false;
        }

        LocalDate today = LocalDate.now();
        
        if (dateOfBirth.isAfter(today)) {
            return false;
        }
        return true;
    }
    public static int calculateAge(String dob) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateOfBirth;
        
        try {
            dateOfBirth = LocalDate.parse(dob, dateFormatter);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format. Please use yyyy-MM-dd.");
        }

        LocalDate today = LocalDate.now();
        
        if (dateOfBirth.isAfter(today)) {
            throw new IllegalArgumentException("Date of birth cannot be in the future.");
        }
        
        return Period.between(dateOfBirth, today).getYears();
    }

}