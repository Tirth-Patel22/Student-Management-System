import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
class SMS{
     static ArrayList<User> al1 = new ArrayList<>();
    static HashMap<Integer,Student> hm =new HashMap<>();
    static Scanner sc = new Scanner(System.in);
    static PreparedStatement pst;
    static Statement st;
    static Connection con;
    static SMS sms=new SMS();
    static String myhistory[]=new String[100];
    static int top=-1;
    static double studentfees=0.0;
    static double studentcredit=0.0;
    static int courseID=0;
    static int foundsid;
  //Node 
  class Node{
    Student s;
    Node next;
    Node(Student s){
        this.s=s;
        this.next=null;
    }
}
Node head1=null;
Node head2=null;
Node head3=null;
Node head4=null;
Node head5=null;

//
    public static void main(String[] args) throws Exception {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        String dbURL = "jdbc:mysql://localhost:3306/studentmanagementsystem";
        String dbUser = "root";
        String dbPass = "";
        int temp = 0;
        con = DriverManager.getConnection(dbURL, dbUser, dbPass);
        if (con != null) {
            try{
             st = con.createStatement();
            System.out.println("Well Come to Student Management System");
            System.out.println("Enter ID");
            int uid = sc.nextInt();
            System.out.println("Enter Password");
            String pass = sc.next();
            String sql = "Select * from admin";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                if (uid == rs.getInt(1) && (pass.equals(rs.getString(4)))) {
                    temp = 1;
                    int c = 1;
                    while (c != 0) {
                        System.out.println("-----------------------------------------------------");
                        System.out.println("Choice your Option");
                        System.out.println("1. ADD Student.");
                        System.out.println("2. Remove Student.");
                        System.out.println("3. Update Student Details.");
                        System.out.println("4. Prepare Topper Student List.");
                        System.out.println("5. Display Details of All Student AND Generate File.");
                        System.out.println("6. Search Student.");
                        System.out.println("7. Display & Delete History.");
                        System.out.println("8. Update Admin Details.");
                        System.out.println("9. Generate File of User Details.");
                        System.out.println("10. Grant Scholarship");
                        System.out.println("11. Revoke Scholarship");
                        System.out.println("12. Check Scholarship Status");
                        System.out.println("13. For EXIT");
                        System.out.println("------------------------------------------------------");
                        System.out.print("Enter Your choice:- ");
                        int choice = sc.nextInt();
                switch (choice) {
                    case 1:sms.addStudent();
                    break;
                    case 2:sms.deleteStudent();
                    break;
                    case 3:sms.updateStudent();
                    break;
                    case 4:sms.generate();
                    break;
                    case 5:sms.displayAllStudent();
                    break;
                    case 6:System.out.println("Enter Student id Number(Sid).");
                    int mysid=sc.nextInt();
                    sms.addToMap(mysid);
                    
                    break;
                            case 7:System.out.println("1. Display History");
                            System.out.println("2. Delete History.");
                            int ch7=sc.nextInt();
                            switch(ch7){
                                case 1:
                                System.out.println("----------------------------------History-----------------------------------------");
                                if(top==-1){
                                    System.out.println("Empty History.");
                                }else{
                                for(int i=top;i>=0;i--){
                                    System.out.println(myhistory[i]);
                                }
                            }
                                System.out.println("----------------------------------------------------------------------------------");
                                break;
                                case 2:sms.pop();
                                break;
                                default:System.out.println("Invalid Choice.");
                            }
                            break;

                            case 8:al1.clear();
                                String sql1 = "Select * from admin";
                                Statement st1 = con.createStatement();
                                ResultSet rst = st1.executeQuery(sql1);
                                while (rst.next()) {
                                    int id = rst.getInt(1);
                                    String name = rst.getString(2);
                                    String mo = rst.getString(3);
                                    String password = rst.getString(4);
                                    User us = new User(id, name, mo, password);
                                    al1.add(us);
                                }
                                System.out.println("1. Update Only Name.");
                                System.out.println("2. Update only Mobile Number.");
                                System.out.println("3. Update only Password.");
                                System.out.println("4. Update All Details.");
                                System.out.println("Else Exit...");
                                int ch8 = sc.nextInt();
                                User us1 = new User();
                                switch (ch8) {
                                    case 1:
                                    sms.push("Update only Name.");
                                        String newname=sms.setName();
                                        int updatenameresult = us1.updateusername(al1, newname, uid);
                                        if (updatenameresult == 0) {
                                            String sql8 = "Update admin SET name=? WHERE id=?";
                                            pst = con.prepareStatement(sql8);
                                            pst.setString(1, newname);
                                            pst.setInt(2, uid);
                                            int nameresult = pst.executeUpdate();
                                            if (nameresult > 0) {
                                                System.out.println("Name update Succesfully TO "+newname);
                                                sms.push("Name update Succesfully TO "+newname);
                                                for (User details : al1) {
                                                    if (details.uid == uid) {
                                                        details.name = newname;
                                                    }
                                                }
                                             
                                            }else{
                                                sms.push("Name Update Failed.");
                                            }
                                        }else{
                                            sms.push("Name Update Failed.");
                                        }
                                        break;
                                    case 2:
                                    sms.push("Update only Mobile Number.");
                                    String newmo=sms.checkNumber();
                                    int updatemoresult=us1.updateusermo(al1, newmo, uid);
                                    if(updatemoresult==0){
                                        String sql8 = "Update admin SET mobile_no=? WHERE id=?";
                                        pst = con.prepareStatement(sql8);
                                        pst.setString(1, newmo);
                                        pst.setInt(2, uid);
                                        int nameresult = pst.executeUpdate();
                                        if (nameresult > 0) {
                                            sms.push("Mobile Number Update Succesfully TO "+newmo);
                                            System.out.println("Password update Succesfully TO"+newmo);
                                            for (User details : al1) {
                                                if (details.uid == uid) {
                                                    details.pass = newmo;
                                                }
                                            }
                                   
                                        }else{
                                            sms.push("Mobile Update Failed.");
                                        }
                                    }else{
                                        sms.push("Mobile Update Failed.");

                                    }                                     

                                        break;
                                    case 3:
                                    sms.push("Update only Password.");
                                    String newpass=sms.setPass();
                                        int updatepassresult = us1.updateuserpassword(al1, newpass, uid);
                                        if (updatepassresult == 0) {
                                            String sql8 = "Update admin SET password=? WHERE id=?";
                                            pst = con.prepareStatement(sql8);
                                            pst.setString(1, newpass);
                                            pst.setInt(2, uid);
                                            int nameresult = pst.executeUpdate();
                                            if (nameresult > 0) {
                                                sms.push("Password Update Succesfully TO "+newpass);
                                                System.out.println("Password update Succesfully TO "+newpass);
                                                for (User details : al1) {
                                                    if (details.uid == uid) {
                                                        details.pass = newpass;
                                                    }
                                                }
                                            
                                            }else{
                                                sms.push("Password Update Failed.");
                                            }
                                        }else{
                                            sms.push("Password Update Failed.");
                                        }

                                        break;

                                    case 4:
                                     sms.push("Update All Details.");
                                     String newname1=sms.setName();
                                        String newmo1=sms.checkNumber();
                                        String newpass1=sms.setPass();
                                        int updateallresult=us1.updateallDetails(al1, newname1, newmo1, newpass1, uid);
                                        if (updateallresult == 0) {
                                                String sql8 = "Update admin SET name=?, mobile_no=?, password=? WHERE id=?";
                                                 pst = con.prepareStatement(sql8);
                                                pst.setString(1, newname1);
                                                pst.setString(2, newmo1);
                                                pst.setString(3, newpass1);
                                                pst.setInt(4, uid);
                                                int allresult = pst.executeUpdate();
                                                    if (allresult > 0) {
                                                        sms.push("All Details Update Succesfully TO "+newname1+","+newmo1+","+newpass1+" respectively.");
                                                        System.out.println("Admin Detail Update Succesfully.");
                                                        for (User details : al1) {
                                                            if (details.uid == uid) {
                                                                details.name = newname1;
                                                                details.mo = newmo1;
                                                                details.pass = newpass1;
                                                                }
                                                            }
                                                         
                                                    }else{
                                                        sms.push("Update for All Details Failed.");
                                                    }
                                        }else{
                                            sms.push("Update for All Details Failed.");
                                        }
                                    }                                                                 
                                break;
                                case 9:sms.push("Download admin Details.");
                                FileWriter fw1=new FileWriter("admin_Details.txt");
                                BufferedWriter bw1=new BufferedWriter(fw1);
                                String sql9="Select * from admin";
                                Statement st9=con.createStatement();
                                ResultSet rs9=st9.executeQuery(sql9);
                                while(rs9.next()){
                                    int id=rs9.getInt(1);
                                    String name=rs9.getString(2);
                                    String mo=rs9.getString(3);
                                    String password=rs9.getString(4);
                                    bw1.write("ID:- "+id+", \nName:- "+name+", \nMobile Number:- "+mo+",\nPassword:- "+password+".");
                                    bw1.newLine();
                                    bw1.write("------------------------------------");
                                    bw1.newLine();
                                }
                                
                                bw1.close();
                                fw1.close();
                                break;
                                case 10:sms.scholar();
                                break;
                                case 11:sms.revoke();
                                break;
                                case 12:sms.checkScholarshipStatus();
                                break;
                                case 13:
                                System.out.println("Thank You");
                                System.exit(0);
                                break;
                                default:System.out.println("Enter Valid Choice.");
                                break;
                    }
            }
        }
        }
            if (temp == 0) {
                System.out.println("Invaild userID or Password");
            }
        }catch(Exception e){
            System.out.println("Invalid Input");
        }
        } else {
            System.out.println("Connection Failed.");
        }

    }
    //Close of Main Method.
    public void push(String s){
        if(top>=myhistory.length){
            System.out.println("You have reach to your Maximun limit.");
        }        
        else{
            top++;
            myhistory[top]=s;
        }

    }
    public void pop(){
        if(top<=-1){
            System.out.println("---------------------");
            System.out.println("No History Found.");
            System.out.println("---------------------");

        }else{
            top--;
        }
    }
    public String checkNumber() throws Exception{
        boolean b=true;
        String newmo="";
        while(b){
        System.out.println("Enter Mobile Number.");
        newmo=sc.next();
        if(newmo.length()==10){
            int count1=0;
            for(int i=0;i<newmo.length();i++){
                if(Character.isDigit((int)newmo.charAt(i))){
                    count1++;
                }else{
                    break;
                }
            }
            if(count1!=10){
                System.out.println("Invalid Mobile Number.");
            }else{
                if (newmo.startsWith("0")||newmo.startsWith("1")||newmo.startsWith("2")||newmo.startsWith("3")||newmo.startsWith("4")||newmo.startsWith("5")) {
                    System.out.println("Invalid Mobile Number.");
                    }else{
                    b=false;
                    }
                
            }
        }else{
            System.out.println("Mobile Number contains only 10 digits.");
        }
    }
        return newmo;
}
public void addToMap(int mysid) throws Exception{
    hm.clear();
    String sql="Select * from student";
    ResultSet rs=st.executeQuery(sql);
    while (rs.next()){
        int sid=rs.getInt(1);
        String fname=rs.getString(2);
        String lname=rs.getString(3);
        String dob=rs.getString(4);
        int age=rs.getInt(5);
        String mo=rs.getString(6);
        String address=rs.getString(7);
        double credit=rs.getDouble(8);
        int depid=rs.getInt(9);
        int cid=rs.getInt(10);
        Double fees=rs.getDouble(11);
        Student s=new Student(sid, fname, lname, age, dob, mo, address, credit, depid, cid, fees);
        hm.put(sid,s);
}
boolean result=hm.containsKey(mysid);
if(result){
    sms.push("Search Student by Sid:-"+mysid+" Succesfully Found.");
   System.out.println(hm.get(mysid));
}else{
    sms.push("Search Student by Sid:-"+mysid+" Not Found.");
    System.out.println("No Student Found with Sid:-"+mysid);
}
}
//method complete.
public void displayAllStudent() throws Exception{
    sms.push("Display All Student Details and Generate File.");
    FileWriter fw=new FileWriter("All_Student_Details.txt");
    BufferedWriter bw=new BufferedWriter(fw);
        String sql="Select * From student";
        ResultSet rs=st.executeQuery(sql);
        while(rs.next()){
            int sid=rs.getInt(1);
            String fname=rs.getString(2);
            String lname=rs.getString(3);
            String dob=rs.getString(4);
            int age=rs.getInt(5);
            String mo=rs.getString(6);
            String address=rs.getString(7);
            double credit=rs.getDouble(8);
            int depid=rs.getInt(9);
            int cid=rs.getInt(10);
            int fees=rs.getInt(11);
            System.out.println("Sid:-"+sid+"\nDepid:-"+depid+"\nCid:-"+cid+"\nFees:-"+fees+"\nFirst Name:-"+fname+"\nLast Name:-"+lname+"\nDOB:-"+dob+"\nAge:-"+age+"\nMobile No:-"+mo+"\nAddress:- "+address+"\nCredit:-"+credit+"\n");
            bw.write("Sid:-"+sid+"\nDepid:-"+depid+"\nCid:-"+cid+"\nFees:-"+fees+"\nFirst Name:-"+fname+"\nLast Name:-"+lname+"\nDOB:-"+dob+"\nAge:-"+age+"\nMobile No:-"+mo+"\nAddress:- "+address+"\nCredit:-"+credit+"\n");
            bw.write("------------------------------------\n");
        }
        bw.close();
        fw.close();
}
public void addStudent() throws Exception{
    Scanner sc=new Scanner(System.in);
    Student s=new Student();
    System.out.println("Enter Student First Name:-");
    String fname=sc.nextLine();
        if(s.checkname(fname)){
        System.out.println("Enter Student Last Name:-");
        String lname=sc.nextLine();
        if(s.checkname(lname)){
            System.out.println("Enter Date of Birth:-");
            System.out.println("Enter Date:-");
            String date=sc.next();
            if(s.check(date)){
                System.out.println("Enter Month:-");
                String month=sc.next();
                if(s.check(month)){
                    System.out.println("Enter Year:-");
                String year=sc.next();
                if(s.check(year)){
                    String dob=year+"-"+month+"-"+date;
                    if(s.isValidDateOfBirth(dob)){
                       int age=s.calculateAge(dob);
                       if(age<=50){
                       // System.out.println("Enter Mobile Number");
                       String mo=checkNumber();
                       String address=sms.getAddress();
                       int depid=getDepId();
                       if(depid!=0){
                       int cid=sms.getCourseID(depid);
                       if(cid!=0){
                        if(setCredit(cid)){
                        String sql="Insert into student(first_name,last_name,date_of_birth,age,mobile_no,address,credit,depid,cid,Fees) Values(?,?,?,?,?,?,?,?,?,?)";
                        pst=con.prepareCall(sql);
                        pst.setString(1,fname);
                        pst.setString(2,lname);
                        pst.setString(3, dob);
                        pst.setInt(4, age);
                        pst.setString(5, mo);
                        pst.setString(6, address);
                        pst.setDouble(7, studentcredit);
                        pst.setInt(8,depid);
                        pst.setInt(9, cid);
                        pst.setDouble(10, studentfees);
                        int addresult=pst.executeUpdate();
                        if(addresult>0){
                            System.out.println("Student Added Succesfully");
                            sms.push("Student Added Succesfully of Name:-"+fname+" "+lname);
                        }else{
                            System.out.println("Student Not Added");
                        }
                    }
                }
                       }
                       //
                       }else{
                        System.out.println("INVALID Date of Birth(age>50)");
                       }
                    }else{
                        System.out.println("INVALID Date OF Birth");
        sms.push("Failed to ADD Student");

                    }
                }else{
                    System.out.println("INVALID Year");
        sms.push("Failed to ADD Student");

                }
                }else{
                    System.out.println("INVALID Month");
        sms.push("Failed to ADD Student");

                }
                
            }else{
                System.out.println("INVALID Date");
        sms.push("Failed to ADD Student");

            }
        }else{
            System.out.println("INVALID Last Name");
        sms.push("Failed to ADD Student");

        }
    }else{
        System.out.println("INVALID First Name");
        sms.push("Failed to ADD Student");
    }
   
}
public int getDepId() throws Exception{
    HashSet<Integer>hs=new HashSet<>();
    
    String sql="select * from department";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        int depid=rs.getInt(1);
        String depname=rs.getString(2);
        double fees=rs.getDouble(3);
        System.out.println("DepID:-"+depid+", DepName:-"+depname+", Fees:-"+fees);
        hs.add(depid);
    }
    System.out.println("Select DepID");
    int selectdepid=sc.nextInt();
    if(hs.contains(selectdepid)){
        setFees(selectdepid);
        return selectdepid;
    }else{
        System.out.println("INVALID DepID");
         sms.push("Failed to ADD Student");
        return 0;
    }
}
public int updateDepId() throws Exception{
    HashSet<Integer>hs=new HashSet<>();
    
    String sql="select * from department";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        int depid=rs.getInt(1);
        String depname=rs.getString(2);
        double fees=rs.getDouble(3);
        System.out.println("DepID:-"+depid+", DepName:-"+depname+", Fees:-"+fees);
        hs.add(depid);
    }
    System.out.println("Select DepID");
    int selectdepid=sc.nextInt();
    if(hs.contains(selectdepid)){
        setFees(selectdepid);
        return selectdepid;
    }else{
        System.out.println("INVALID DepID");
    sms.push("Failed to Update Department, course and credit for sid:-"+foundsid);
        return 0;
    }
}
public int getCourseID(int depid) throws Exception{
    HashSet<Integer>hs=new HashSet<>();
String sql="Select cid,course_name from course where dep_id='"+depid+"'";
ResultSet rs=st.executeQuery(sql);
while(rs.next()){
    int cid=rs.getInt("cid");
    String cname=rs.getString("course_name");
    System.out.println("CID:-"+cid+", Course Name:-"+cname);
    hs.add(cid);
}
System.out.println("Select cid");
int cid=sc.nextInt();
if(hs.contains(cid)){
    return cid;
}else{
    System.out.println("INVALID CID");
    sms.push("Failed to ADD Student");
    return 0;
}
}
public int updateCourseID(int depid) throws Exception{
    HashSet<Integer>hs=new HashSet<>();
String sql="Select cid,course_name from course where dep_id='"+depid+"'";
ResultSet rs=st.executeQuery(sql);
while(rs.next()){
    int cid=rs.getInt("cid");
    String cname=rs.getString("course_name");
    System.out.println("CID:-"+cid+", Course Name:-"+cname);
    hs.add(cid);
}
System.out.println("Select cid");
int cid=sc.nextInt();
if(hs.contains(cid)){
    return cid;
}else{
    System.out.println("INVALID CID");
    sms.push("Failed to Update Department, course and credit for sid:-"+foundsid);
    return 0;
}
}
public boolean setCredit(int cid) throws Exception{
    double totalcredit=0;
    String sql="Select total_credit from course where cid='"+cid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        totalcredit=rs.getDouble("total_credit");
    }
    System.out.println("Enter Credit");
    studentcredit=sc.nextDouble();
    if(studentcredit>=0 && studentcredit<=totalcredit){
        return true;
    }else{
        System.out.println("INVALID Credit");
        sms.push("Failed to ADD Student");
        
        return false;
    }
}
public boolean updateCredit(int cid) throws Exception{
    double totalcredit=0;
    String sql="Select total_credit from course where cid='"+cid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        totalcredit=rs.getDouble("total_credit");
    }
    System.out.println("Enter Credit");
    studentcredit=sc.nextDouble();
    if(studentcredit>=0 && studentcredit<=totalcredit){
        return true;
    }else{
        System.out.println("INVALID Credit");
        sms.push("Failed to Update Department, course and credit for sid:-"+foundsid);
        
        return false;
    }
}
public void setFees(int depid) throws Exception{
    String sql="Select fees from department where dep_id='"+depid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        studentfees=rs.getInt("fees");
    }
}
public void deleteStudent() throws Exception{
    System.out.println("Enter Sid of Student you want to Delete");
    int sid=sc.nextInt();
    String sql="Delete From student where sid='"+sid+"'";
    int deleteresult=st.executeUpdate(sql);
    if(deleteresult>0){
        System.out.println("Student Deleted of Sid:-"+sid+" Succesfully");
        sms.push("Student Deleted of Sid:-"+sid+" Succesfully");
    }else{
        System.out.println("Student Not Found");
        sms.push("Student Deleted of Sid:-"+sid+" Failed");
    }
}
public void updateStudent()throws Exception{
    Scanner sc=new Scanner(System.in);
    Student s=new Student();
    foundsid=0;
    System.out.println("Enter Sid of Student which you want to update");
    int sid=sc.nextInt();
    String sql="Select * FROM student where sid='"+sid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        foundsid=rs.getInt(1);
    }
    if(foundsid==sid){
        boolean b=true;
        while(b){
            System.out.println("Enter 1: Update First Name");
            System.out.println("Enter 2: Update Last Name");
            System.out.println("Enter 3: Update Date of Birth");
            System.out.println("Enter 4: Update Mobile Number");
            System.out.println("Enter 5: Update Address");
            System.out.println("Enter 6: Update Department,Course and credit");
            System.out.println("else Exit...");
            int ch=sc.nextInt();
            switch(ch){
                case 1:System.out.println("Enter First Name");
                sc.nextLine();
                String fname=sc.nextLine();
                    if(s.checkname(fname)){
                    String sql1="update student set first_name='"+fname+"' where sid='"+foundsid+"'";
                    st=con.createStatement();
                    int rs1=st.executeUpdate(sql1);
                    if(rs1>0){
                        System.out.println("First Name Updated succesfully to "+fname);
                        sms.push("First Name Updated succesfully to "+fname+" for sid:-"+foundsid);
                    }
                }else{
                    System.out.println("Invalid Name");
                    sms.push("Failed to Update First Name for sid:-"+foundsid);
                }
                break;
                case 2:System.out.println("Enter Last Name");
                sc.nextLine();
                String lname=sc.nextLine();
                if(s.checkname(lname)){
                    String sql2="update student set last_name='"+lname+"' where sid='"+foundsid+"'";
                    st=con.createStatement();
                    int rs2=st.executeUpdate(sql2);
                    if(rs2>0){
                        System.out.println("Last Name Updated succesfully to "+lname);
                        sms.push("Last Name Updated succesfully to "+lname+" for sid:-"+foundsid);
                    }
                }else{
                    System.out.println("Invalid Name");
                    sms.push("Failed to Update Last Name for sid:-"+foundsid);

                }
                break;
                case 3:System.out.println("Enter New Date of Birth");
                System.out.println("Enter Date:-");
                String date=sc.next();
                if(s.check(date)){
                    System.out.println("Enter Month");
                    String month=sc.next();
                    if(s.check(month)){
                        System.out.println("Enter Year");
                        String year=sc.next();
                        if(s.check(year)){
                            String dob=year+"-"+month+"-"+date;
                            if(s.isValidDateOfBirth(dob)){
                                int age=s.calculateAge(dob);
                                if(age<50){
                                String sql3="update student set date_of_birth='"+dob+"',age='"+age+"' where sid='"+foundsid+"'";
                    st=con.createStatement();
                    int rs3=st.executeUpdate(sql3);
                    if(rs3>0){
                        System.out.println("Date of Birth Updated succesfully to "+dob);
                        sms.push("Date of Birth Updated succesfully to "+dob+" for sid:-"+foundsid);
                    }else{
                        sms.push("Failed to update Date of Birth for sid:-"+foundsid);
                    }
                }else{
                    System.out.println("Invalid Date of Birth(age>50)");
                    sms.push("Failed to update Date of Birth for sid:-"+foundsid);

                }
                            }else{
                                System.out.println("Invalid Date of Birth");
                        sms.push("Failed to update Date of Birth for sid:-"+foundsid);

                            }
                        }else{
                            System.out.println("Invalid Year");
                        sms.push("Failed to update Date of Birth for sid:-"+foundsid);

                        }
                    }else{
                        System.out.println("Invalid Month");
                        sms.push("Failed to update Date of Birth for sid:-"+foundsid);

                    }
                }else{
                    System.out.println("Invalid Date");
                    sms.push("Failed to update Date of Birth for sid:-"+foundsid);

                }
                break;
                case 4:String mo=checkNumber();
                String sql4="update student set mobile_no='"+mo+"'where sid='"+foundsid+"'";
                    st=con.createStatement();
                    int rs4=st.executeUpdate(sql4);
                    if(rs4>0){
                        System.out.println("Mobile Number Updated succesfully to "+mo);
                        sms.push("Mobile Number Updated succesfully to "+mo+" for sid:-"+foundsid);
                    }else{
                        sms.push("Failed to update Mobile Number for sid:-"+foundsid);
                    }
                break;
                case 5:
                String address=sms.getAddress();
                String sql5="update student set address='"+address+"'where sid='"+foundsid+"'";
                st=con.createStatement();
                int rs5=st.executeUpdate(sql5);
                if(rs5>0){
                    System.out.println("Address Updated succesfully to "+address);
                    sms.push("Address Updated succesfully to "+address+" for sid:-"+foundsid);
                }else{
                    sms.push("Failed to update Address for sid:-"+foundsid);
                }
                break;
                case 6:
                    int depid=updateDepId();
                        if(depid!=0){
                            int cid=sms.updateCourseID(depid);
                               if(cid!=0){
                                    if(updateCredit(cid)){
                                        String sql6="update student set depid='"+depid+"',cid='"+cid+"',credit='"+studentcredit+"'where sid='"+foundsid+"'";
                                            st=con.createStatement();
                                            int rs6=st.executeUpdate(sql6);
                                                if(rs6>0){
                                                  System.out.println("Department, course and credit updated succesfully to "+depid+"-"+cid+"-"+studentcredit+" respectively");
                                                  sms.push("Department, course and credit updated succesfully to "+depid+"-"+cid+"-"+studentcredit+" respectively");
                                            }else{
                                             sms.push("Failed to Update Department, course and credit for sid:-"+foundsid);
                                        }
                                    }
                                }
                            }
                break;
                default:b=false;
            }
        }
        // System.out.println("Enter new First Name");
        // String fname=sc.next();
        // if(s.checkname(fname)){
        //     System.out.println("Enter new Last Name");
        // String lname=sc.next();
        // if(s.checkname(lname)){
        //     System.out.println("Enter new Date of Birth:-");
        //     System.out.println("Enter Date:-");
        //     String date=sc.next();
        //     if(s.check(date)){
        //         System.out.println("Enter Month:-");
        //         String month=sc.next();
        //         if(s.check(month)){
        //             System.out.println("Enter Year:-");
        //         String year=sc.next();
        //         if(s.check(year)){
        //             String dob=year+"-"+month+"-"+date;
        //             if(s.isValidDateOfBirth(dob)){
        //                int age=s.calculateAge(dob);
        //                if(age<=50){
        //                String mo=checkNumber();
        //                String address=sms.getAddress();
        //                int depid=getDepId();
        //                if(depid!=0){
        //                int cid=sms.getCourseID(depid);
        //                if(cid!=0){
        //                 if(setCredit(cid)){
        //                String updateStudent="UPDATE student SET first_name=?,last_name=?,date_of_birth=?,age=?,mobile_no=?,address=?,credit=?,depid=?,cid=?,Fees=? WHERE sid= '"+foundsid+"'";
        //                pst=con.prepareCall(updateStudent);
        //                pst.setString(1,fname);
        //                 pst.setString(2,lname);
        //                 pst.setString(3, dob);
        //                 pst.setInt(4, age);
        //                 pst.setString(5, mo);
        //                 pst.setString(6, address);
        //                 pst.setDouble(7, studentcredit);
        //                 pst.setInt(8,depid);
        //                 pst.setInt(9, cid);
        //                 pst.setDouble(10, studentfees);
        //                int updateresult=pst.executeUpdate();
        //                if(updateresult>0){
        //                 sms.push("Student Updated Succesfully");
        //                 System.out.println("Student Updated Succesfully");
        //                }else{
        //                 System.out.println("Student Updated Unsuccesfully");
        //                }
        //             }
        //         }
        //                }
        //                //
        //                }else{
        //                 System.out.println("INVALID Date of Birth(age>50)");
        //                }
        //             }else{
        //                 System.out.println("INVALID Date OF Birth");
        // sms.push("Failed to Update Student");

        //             }
        //         }else{
        //             System.out.println("INVALID Year");
        // sms.push("Failed to Update Student");

        //         }
        //         }else{
        //             System.out.println("INVALID Month");
        // sms.push("Failed to Update Student");

        //         }
                
        //     }else{
        //         System.out.println("INVALID Date");
        // sms.push("Failed to Update Student");

        //     }
        //     //
        // }else{
        //     System.out.println("INVALID Last Name");
        //     sms.push("Failed to Update Student");
        // }  
        // }else{
        //     System.out.println("INVALID First Name");
        // sms.push("Failed to Update Student");
        // }
    }else{
        System.out.println("Sid Not Found");
        sms.push("Failed to Update Student");
    }
}
public void insert1(Student student) {
    Node newNode = new Node(student);
    if (head1 == null || head1.s.credit < newNode.s.credit) {
        newNode.next = head1;
        head1 = newNode;
    } else {
        Node current = head1;
        while (current.next != null && current.next.s.credit >= newNode.s.credit) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }
}
public void insert2(Student student) {
    Node newNode = new Node(student);
    if (head2 == null || head2.s.credit < newNode.s.credit) {
        newNode.next = head2;
        head2 = newNode;
    } else {
        Node current = head2;
        while (current.next != null && current.next.s.credit >= newNode.s.credit) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }
}public void insert3(Student student) {
    Node newNode = new Node(student);
    if (head3 == null || head3.s.credit < newNode.s.credit) {
        newNode.next = head3;
        head3 = newNode;
    } else {
        Node current = head3;
        while (current.next != null && current.next.s.credit >= newNode.s.credit) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }
}public void insert4(Student student) {
    Node newNode = new Node(student);
    if (head4 == null || head4.s.credit < newNode.s.credit) {
        newNode.next = head4;
        head4 = newNode;
    } else {
        Node current = head4;
        while (current.next != null && current.next.s.credit >= newNode.s.credit) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }
}public void insert5(Student student) {
    Node newNode = new Node(student);
    if (head5 == null || head5.s.credit < newNode.s.credit) {
        newNode.next = head5;
        head5 = newNode;
    } else {
        Node current = head5;
        while (current.next != null && current.next.s.credit >= newNode.s.credit) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }
}
void scholar() throws Exception{
    int foundsid=0;
    double credit=0;
    String fname="";
    String lname="";
    double amount=0;
    System.out.println("Enter Sid of Student");
    int sid=sc.nextInt();
    String sql="Select * FROM student where sid='"+sid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        foundsid=rs.getInt(1);
        fname=rs.getString(2);
        lname=rs.getString(3);
        credit=rs.getDouble(8);
    }
    if(foundsid==sid){
        if(credit>20.00){
            System.out.println("Enter Amount");
            amount=sc.nextDouble();
            String sql1="call getScholarship(?,?,?,?)";
            CallableStatement cst=con.prepareCall(sql1);
            cst.setInt(1, foundsid);
            cst.setString(2, fname);
            cst.setDouble(3, amount);
            cst.setString(4, lname);
            cst.execute();
            System.out.println("ScholarShip Allowted to "+fname+" "+lname+" of Rs:"+amount);
        }else{
            System.out.println("Student is not Eligible for Scholarship");
        }
    }else{
        System.out.println("No Student Found");
    }
    sms.push("Give ScholarShip");
}
void checkScholarshipStatus() throws Exception{
    int foundsid=0;
    double credit=0;
    System.out.println("Enter Sid of Student");
    int sid=sc.nextInt();
    String sql="Select * FROM student where sid='"+sid+"'";
    ResultSet rs=st.executeQuery(sql);
    while(rs.next()){
        foundsid=rs.getInt(1);
        credit=rs.getDouble(8);
    }
    if(foundsid==sid){
    String sql1="call checkStatus(?,?,?)";
    CallableStatement cst=con.prepareCall(sql1);
    cst.setInt(1, foundsid);
    cst.execute();
    int check=cst.getInt(2);
    double amt=cst.getDouble(3);
    if(check>0){
        System.out.println("Scholarship is Granted of Rs "+amt);
    }else{
        if(credit>20.00){
            System.out.println("ScholarShip is Not Granted But Can be Applied");
        }else{
            System.out.println("Student is not Eligible for Scholarship");
        }
    }

    }else{
        sms.push("Failed check Scholarship");
        System.out.println("No Student Found");
    }
    sms.push("check ScholarShip Status");

}

public void generate() throws Exception{
    deleteAll();
    System.out.println("Enter course ID:-");
    int id=sc.nextInt();
    if(id>0 && id<=5){
        courseID=id;
    String sql="Select * from student where cid='"+id+"'";
    ResultSet rs=st.executeQuery(sql);
    while (rs.next()){
        int sid=rs.getInt(1);
        String fname=rs.getString(2);
        String lname=rs.getString(3);
        String dob=rs.getString(4);
        int age=rs.getInt(5);
        String mo=rs.getString(6);
        String address=rs.getString(7);
        double credit=rs.getDouble(8);
        int depid=rs.getInt(9);
        int cid=rs.getInt(10);
        Double fees=rs.getDouble(11);
        Student s=new Student(sid, fname, lname, age, dob, mo, address, credit, depid, cid, fees);
        if(id==1){
        insert1(s);
        display1();
        }else if(id==2){
            insert2(s);
        display2();
        }else if(id==3){
            insert3(s);
            display3();
        }else if(id==4){
            insert4(s);
            display4();
        }else{
            insert5(s);
            display5();
        }
    }
    sms.push("Generate Top Student List for CID:-"+id);
}else{
    System.out.println("Invalid Course ID");
}
}
public void display1()throws Exception {
    BufferedWriter bw=new BufferedWriter(new FileWriter("List_for_cid_1.txt"));
    Node current = head1;
    while (current != null) {
        
        bw.write("Full Name:-"+current.s.fname+" "+current.s.lname);
        bw.write("\nSid:-"+current.s.sid+"\nDepid:-"+current.s.depid+"\nCid:-"+current.s.cid+"\nFees:-"+current.s.fees+"\nFirst Name:-"+current.s.fname+"\nLast Name:-"+current.s.lname+"\nDOB:-"+current.s.dob+"\nAge:-"+current.s.age+"\nMobile No:-"+current.s.mobileno+"\nAddress:- "+current.s.address+"\nCredit:-"+current.s.credit+"\n");
        
        bw.write("--------------------------");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}
public void display2()throws Exception {
    BufferedWriter bw=new BufferedWriter(new FileWriter("List_for_cid_2.txt"));
    Node current = head2;
    while (current != null) {
        
        bw.write("Full Name:-"+current.s.fname+" "+current.s.lname);
        bw.write("\nSid:-"+current.s.sid+"\nDepid:-"+current.s.depid+"\nCid:-"+current.s.cid+"\nFees:-"+current.s.fees+"\nFirst Name:-"+current.s.fname+"\nLast Name:-"+current.s.lname+"\nDOB:-"+current.s.dob+"\nAge:-"+current.s.age+"\nMobile No:-"+current.s.mobileno+"\nAddress:- "+current.s.address+"\nCredit:-"+current.s.credit+"\n");
        
        bw.write("--------------------------");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}public void display3()throws Exception {
    BufferedWriter bw=new BufferedWriter(new FileWriter("List_for_cid_3.txt"));
    Node current = head3;
    while (current != null) {
        
        bw.write("Full Name:-"+current.s.fname+" "+current.s.lname);
        bw.write("\nSid:-"+current.s.sid+"\nDepid:-"+current.s.depid+"\nCid:-"+current.s.cid+"\nFees:-"+current.s.fees+"\nFirst Name:-"+current.s.fname+"\nLast Name:-"+current.s.lname+"\nDOB:-"+current.s.dob+"\nAge:-"+current.s.age+"\nMobile No:-"+current.s.mobileno+"\nAddress:- "+current.s.address+"\nCredit:-"+current.s.credit+"\n");
        
        bw.write("--------------------------");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}public void display4()throws Exception {
    BufferedWriter bw=new BufferedWriter(new FileWriter("List_for_cid_4.txt"));
    Node current = head4;
    while (current != null) {
        
        bw.write("Full Name:-"+current.s.fname+" "+current.s.lname);
        bw.write("\nSid:-"+current.s.sid+"\nDepid:-"+current.s.depid+"\nCid:-"+current.s.cid+"\nFees:-"+current.s.fees+"\nFirst Name:-"+current.s.fname+"\nLast Name:-"+current.s.lname+"\nDOB:-"+current.s.dob+"\nAge:-"+current.s.age+"\nMobile No:-"+current.s.mobileno+"\nAddress:- "+current.s.address+"\nCredit:-"+current.s.credit+"\n");
        
        bw.write("--------------------------");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}public void display5()throws Exception {
    BufferedWriter bw=new BufferedWriter(new FileWriter("List_for_cid_5.txt"));
    Node current = head5;
    while (current != null) {
        
        bw.write("Full Name:-"+current.s.fname+" "+current.s.lname);
        bw.write("\nSid:-"+current.s.sid+"\nDepid:-"+current.s.depid+"\nCid:-"+current.s.cid+"\nFees:-"+current.s.fees+"\nFirst Name:-"+current.s.fname+"\nLast Name:-"+current.s.lname+"\nDOB:-"+current.s.dob+"\nAge:-"+current.s.age+"\nMobile No:-"+current.s.mobileno+"\nAddress:- "+current.s.address+"\nCredit:-"+current.s.credit+"\n");
        
        bw.write("--------------------------");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}
public void deleteAll() {
    Node current1 = head1;
    Node current2 = head2;
    Node current3 = head3;
    Node current4 = head4;
    Node current5 = head5;

    Node nextNode;

    while (current1 != null) {
        nextNode = current1.next; 
        current1.next = null;      
        current1 = nextNode;      
    }
    while (current2 != null) {
        nextNode = current2.next; 
        current2.next = null;      
        current2 = nextNode;      
    }
    while (current3 != null) {
        nextNode = current3.next; 
        current3.next = null;      
        current3 = nextNode;      
    }
    while (current4 != null) {
        nextNode = current4.next; 
        current4.next = null;      
        current4 = nextNode;      
    }
    while (current5 != null) {
        nextNode = current5.next; 
        current5.next = null;      
        current5 = nextNode;      
    }
    head1 = null;
    head2 = null;
    head3 = null;
    head4 = null;
    head5 = null;

}
public String getAddress() {
    Scanner sc=new Scanner(System.in);
    String address;
    while (true) {
        System.out.println("Enter Address (only alphabets, digits, '-', and spaces are allowed):");
        //sc.nextLine();
        address = sc.nextLine();
        if (isValidAddress(address)) {
            break;
        } else {
            System.out.println("Invalid address. Please try again.");
        }
    }
    return address;
}

private static boolean isValidAddress(String address) {
    for (int i = 0; i < address.length(); i++) {
        char ch = address.charAt(i);
        if (!isAllowedCharacter(ch)) {
            return false;
        }
    }
    return true;
}

private static boolean isAllowedCharacter(char ch) {
    return (Character.isLetter(ch) || Character.isDigit(ch) || ch == '-' || ch == ' ');
}
public void revoke() throws Exception{
    System.out.println("Enter Student Id");
    int id=sc.nextInt();
    String sql="call deleteScholarship(?)";
    CallableStatement cst=con.prepareCall(sql);
    cst.setInt(1, id);
    int rs=cst.executeUpdate();
    if(rs>0){
        System.out.println("Scholarship is Revoke succesfully");
        sms.push("Scholarship is Revoke succesfully of Sid:-"+id);
    }else{
        System.out.println("No Student Found");
        sms.push("Failed to Revoke Scholarship of Sid:-"+id);
    }
}
public String setPass(){
    Scanner sc=new Scanner(System.in);
    boolean b=true;
    String pass="";
    while(b){
    System.out.println("Enter Password");
    pass=sc.nextLine();
    if(pass.length()>8 || pass.length()<8){
        System.out.println("Password Length should be 8");
    }else{
        if(pass.equalsIgnoreCase("00000000")){
            System.out.println("Invalid Password");
        }else{
            if(pass.contains(" ")){
                b=true;
            }else{
                b=false;
            }
        }
    }
}
return pass;
}
public String setName(){
    Scanner sc=new Scanner(System.in);
    boolean b=true;
    String name="";
    while(b){
    System.out.println("Enter Name");
    name=sc.nextLine();
        if(name.equalsIgnoreCase("00000000")){
            System.out.println("Invalid Name");
        }else{
            b=false;
        }
}
return name;
}
public String setStudentName(){
    Scanner sc=new Scanner(System.in);
    boolean b=true;
    String name="";
    while(b){
    System.out.println("Enter Name");
    name=sc.nextLine();
        if(name.equalsIgnoreCase("00000000")){
            System.out.println("Invalid Name");
        }else{
            if(name.contains(" ")){
                b=true;
            }else{
            b=false;
            }
        }
}
return name;
}
}