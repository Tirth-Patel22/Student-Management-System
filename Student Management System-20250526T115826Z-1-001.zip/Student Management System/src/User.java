import java.sql.PreparedStatement;
import java.util.ArrayList;

public class User {
    int uid;
    String name;
    String mo;
    String pass;

    public User(int uid, String name, String mo, String pass) {
        this.uid = uid;
        this.name = name;
        this.mo = mo;
        this.pass = pass;
    }

    public User() {
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("User{");
        sb.append("uid=").append(uid);
        sb.append(", name=").append(name);
        sb.append(", mo=").append(mo);
        sb.append(", pass=").append(pass);
        sb.append('}');
        return sb.toString();
    }

    public int updateallDetails(ArrayList<User> al1, String name1, String mo1, String pass1, int id) throws Exception {
        PreparedStatement pst;
        int temp = 0;
        for (User details : al1) {
            if (details.uid == id) {
                if (details.name.equalsIgnoreCase(name1)) {
                    System.out.println("New and Old Name can not be same.");
                    temp = 1;
                } else {

                    if (details.mo.equalsIgnoreCase(mo1)) {
                        System.out.println("Old and New Mobile Number can not be same.");
                        temp = 1;
                    } else {
                        if (details.pass.equalsIgnoreCase(pass1)) {
                            System.out.println("Old and New Password can not be same.");
                            temp = 1;
                        }
                    }
                }
            }

        }
        return temp;
    }

    public int updateusername(ArrayList<User> al1, String newname, int id) {
        int temp = 0;
        for (User details : al1) {
            if (details.uid == id) {
                if (details.name.equalsIgnoreCase(newname)) {
                    System.out.println("Old and New Name can not be same.");
                    temp = 1;
                }
            }
        }
        return temp;
    }

    public int updateusermo(ArrayList<User> al1, String newmo, int id) {
        int temp = 0;
        for (User details : al1) {
            if (details.uid == id) {
                if (details.mo.equals(newmo)) {
                    System.out.println("Old and New Mobile Number can not be same.");
                    temp = 1;
                }
            }
        }
        return temp;
    }

    public int updateuserpassword(ArrayList<User> al1, String newpass, int id) {
        int temp = 0;
        for (User details : al1) {
            if (details.uid == id) {
                if (details.pass.equalsIgnoreCase(newpass)) {
                    System.out.println("Old and New Password can not be same.");
                    temp = 1;
                }
            }
        }
        return temp;
    }
    
}