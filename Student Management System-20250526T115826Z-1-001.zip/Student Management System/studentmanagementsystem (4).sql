-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2024 at 10:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmanagementsystem`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkStatus` (IN `id` INT, OUT `row` INT, OUT `amt` DOUBLE)   select count(*),amount INTO row,amt from scholarship where sid=id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteScholarship` (IN `myid` INT)   DELETE FROM scholarship where sid=myid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getScholarship` (IN `id` INT, IN `fname` VARCHAR(50), IN `amount` DECIMAL, IN `lname` VARCHAR(50))   INSERT INTO scholarship (sid,first_name,last_name,Amount) VALUES (id,fname,lname,amount)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `mobile_no`, `password`) VALUES
(1, 'Tirth Patel', 9313568134, 'tirth@22');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `cid` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `total_credit` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`cid`, `dep_id`, `course_name`, `total_credit`) VALUES
(1, 1, 'Computer Engineering', 30),
(2, 1, 'Software Engineering', 30),
(3, 3, 'Electrical Engineering', 30),
(4, 2, 'Civil Engineering', 30),
(5, 3, 'Mechanical Engineering', 30);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` int(11) NOT NULL,
  `dep_name` varchar(50) NOT NULL,
  `fees` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `dep_name`, `fees`) VALUES
(1, 'FY1', 95000),
(2, 'FY2', 90000),
(3, 'FY3', 85000);

-- --------------------------------------------------------

--
-- Table structure for table `scholarship`
--

CREATE TABLE `scholarship` (
  `scholarship_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `Amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(11) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `credit` double NOT NULL,
  `depid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `Fees` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `first_name`, `last_name`, `date_of_birth`, `age`, `mobile_no`, `address`, `credit`, `depid`, `cid`, `Fees`) VALUES
(22, 'Atul', 'Sharma', '2004-07-10', 20, 9313568134, 'mulund-west-kurla', 19.9, 2, 4, 90000),
(24, 'smit', 'chhabhaiya', '2004-03-18', 20, 9313585252, 'khirsara-roha', 20.6, 1, 2, 95000),
(25, 'jay', 'pokar', '2003-02-01', 21, 8511374366, 'mumbai-navi', 28.23, 1, 2, 95000),
(26, 'vipul', 'ramani', '2001-01-14', 23, 9636985258, 'rajkot-gujarat', 19.36, 1, 2, 95000),
(27, 'kush', 'mavani', '2006-01-22', 18, 9313568134, 'dujapar', 20.3, 1, 2, 95000),
(28, 'tirth', 'patel', '2006-01-22', 18, 9313568134, 'khirsara', 22.3, 1, 1, 95000),
(29, 'dheer', 'mavani', '2009-10-25', 14, 8511374366, 'khiresara', 19.36, 1, 1, 95000),
(31, 'nishit', 'chhabhaiya', '2004-09-17', 19, 9874563214, 'thane-thikuhgi', 23.5, 1, 1, 95000),
(32, 'poojan', 'pokar', '2004-01-14', 20, 8523696666, 'chiloda', 19.2, 1, 1, 95000),
(33, 'jay', 'parasiya', '2003-02-01', 21, 8989898888, 'gvbrf', 18.23, 1, 2, 95000);

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `deleteScholarship` AFTER DELETE ON `student` FOR EACH ROW DELETE from scholarship where sid=old.sid
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateCredit` AFTER UPDATE ON `student` FOR EACH ROW IF new.credit<20.00 THEN
DELETE FROM scholarship where sid=old.sid;
END IF
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateScholarship` AFTER UPDATE ON `student` FOR EACH ROW UPDATE scholarship set first_name=new.first_name,last_name=new.last_name where first_name=old.first_name AND last_name=old.last_name
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `scholarship`
--
ALTER TABLE `scholarship`
  ADD PRIMARY KEY (`scholarship_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `scholarship`
--
ALTER TABLE `scholarship`
  MODIFY `scholarship_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
